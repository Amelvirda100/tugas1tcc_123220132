import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import KamarList from './components/kamar/KamarList';
import AddKamar from './components/kamar/AddKamar';
import EditKamar from './components/kamar/EditKamar';
import Login from "./components/Login.jsx";
import Register from "./components/Register.jsx";

function App() {
  const token = localStorage.getItem("token");

  return (
    <Router>
      <Routes>
        {/* Default route: Redirect to login */}
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Auth routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Protected Kamar routes */}
        <Route
          path="/kamar"
          element={token ? <KamarList /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/kamar/add"
          element={token ? <AddKamar /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/kamar/edit/:id"
          element={token ? <EditKamar /> : <Navigate to="/login" replace />}
        />
      </Routes>
    </Router>
  );
}

export default App;
