import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const KamarList = () => {
  const [kamar, setKamar] = useState([]);

  const fetchData = async () => {
    try {
      const res = await axios.get('http://localhost:5000/kamar');
      setKamar(res.data);
    } catch (error) {
      console.error('Gagal mengambil data kamar:', error);
    }
  };

  const deleteKamar = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/kamar/${id}`);
      fetchData();
    } catch (error) {
      console.error('Gagal menghapus kamar:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="columns is-centered mt-5">
      <div className="column is-10">
        <Link to="/kamar/add" className="button is-primary is-light mb-4">➕ Tambah Kamar</Link>
        <table className="table is-fullwidth is-striped is-hoverable">
          <thead>
            <tr>
              <th>No</th>
              <th>Nomor</th>
              <th>Tipe</th>
              <th>Harga</th>
              <th>Status</th>
              <th>Fasilitas</th> {/* Tampilkan fasilitas juga */}
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {kamar.map((k, i) => (
              <tr key={k.kamar_id}>
                <td>{i + 1}</td>
                <td>{k.nomor_kamar}</td>
                <td>{k.tipe_kamar}</td>
                <td>{k.harga}</td>
                <td>{k.status}</td>
                <td>{k.fasilitas}</td> {/* tampilkan fasilitas */}
                <td>
                  <Link to={`/kamar/edit/${k.kamar_id}`} className="button is-small is-info is-light mr-2">✏️</Link>
                  <button onClick={() => deleteKamar(k.kamar_id)} className="button is-small is-danger is-light">🗑️</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default KamarList;
