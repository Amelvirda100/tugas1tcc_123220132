import { useEffect, useState } from "react";
import { Card, CardContent } from "./ui/card";
import { Bed, ClipboardList, Users, LogOut } from "lucide-react";

// API URL backend kamu
const API_URL = "http://localhost:5000";

export default function Dashboard() {
  const [totalKamar, setTotalKamar] = useState(0);
  const [totalPenyewa, setTotalPenyewa] = useState(0);
  const [sewaAktif, setSewaAktif] = useState(0);

  useEffect(() => {
    // Ambil data kamar
    fetch(`${API_URL}/kamar`)
      .then((res) => res.json())
      .then((data) => setTotalKamar(data.length))
      .catch((err) => console.error("Gagal ambil kamar", err));

    // Ambil data penyewa
    fetch(`${API_URL}/penyewa`)
      .then((res) => res.json())
      .then((data) => setTotalPenyewa(data.length))
      .catch((err) => console.error("Gagal ambil penyewa", err));

    // Ambil data sewa & filter yang aktif
    fetch(`${API_URL}/sewa`)
      .then((res) => res.json())
      .then((data) => {
        const aktif = data.filter((item) => item.status === "aktif");
        setSewaAktif(aktif.length);
      })
      .catch((err) => console.error("Gagal ambil sewa", err));
  }, []);

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900 dark:bg-neutral-900 dark:text-neutral-100">
      {/* Navbar */}
      <nav className="flex items-center justify-between bg-neutral-200 dark:bg-neutral-800 px-6 py-4 shadow-md">
        <div className="text-2xl font-bold">Babarsari Kos</div>
        <div className="flex gap-6 items-center">
          <a href="#" className="flex items-center gap-2 hover:text-blue-600"><Bed size={20}/>Kamar List</a>
          <a href="#" className="flex items-center gap-2 hover:text-blue-600"><ClipboardList size={20}/>Sewa List</a>
          <a href="#" className="flex items-center gap-2 hover:text-blue-600"><Users size={20}/>Penyewa List</a>
          <a href="#" className="flex items-center gap-2 hover:text-red-500"><LogOut size={20}/>Logout</a>
        </div>
      </nav>

      {/* Main Content */}
      <main className="p-6 grid gap-6">
        <h1 className="text-xl font-semibold">Dashboard Admin Kos</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Total Kamar</div>
              <div className="text-2xl font-bold">{totalKamar}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Total Penyewa</div>
              <div className="text-2xl font-bold">{totalPenyewa}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Sewa Aktif</div>
              <div className="text-2xl font-bold">{sewaAktif}</div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
