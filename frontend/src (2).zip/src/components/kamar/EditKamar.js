import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const EditKamar = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [nomor_kamar, setNomorKamar] = useState('');
  const [tipe_kamar, setTipeKamar] = useState('');
  const [harga, setHarga] = useState('');
  const [status, setStatus] = useState('kosong');
  const [fasilitas, setFasilitas] = useState('');

  useEffect(() => {
    const fetchKamar = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/kamar/${id}`);
        setNomorKamar(res.data.nomor_kamar);
        setTipeKamar(res.data.tipe_kamar);
        setHarga(res.data.harga);
        setStatus(res.data.status);
        setFasilitas(res.data.fasilitas || '');
      } catch (err) {
        console.error(err);
        alert('Gagal mengambil data kamar');
      }
    };
    fetchKamar();
  }, [id]);

  const updateKamar = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/kamar/${id}`, {
        nomor_kamar,
        tipe_kamar,
        harga,
        status,
        fasilitas
      });
      navigate('/kamar'); // arahkan ke list kamar
    } catch (err) {
      console.error(err);
      alert('Gagal mengupdate kamar');
    }
  };

  return (
    <div className="columns is-centered mt-5">
      <div className="column is-half">
        <form onSubmit={updateKamar} className="box">
          <h3 className="title is-4">Edit Kamar</h3>

          <div className="field">
            <label className="label">Nomor Kamar</label>
            <input className="input" type="text" value={nomor_kamar} onChange={(e) => setNomorKamar(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Tipe Kamar</label>
            <input className="input" type="text" value={tipe_kamar} onChange={(e) => setTipeKamar(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Harga</label>
            <input className="input" type="number" value={harga} onChange={(e) => setHarga(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Fasilitas</label>
            <textarea
              className="textarea"
              value={fasilitas}
              onChange={(e) => setFasilitas(e.target.value)}
              placeholder="Masukkan fasilitas, pisahkan dengan koma"
            />
          </div>

          <div className="field">
            <label className="label">Status</label>
            <div className="select is-fullwidth">
              <select value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="kosong">Kosong</option>
                <option value="terisi">Terisi</option>
              </select>
            </div>
          </div>

          <button type="submit" className="button is-warning is-light mt-4">🔄 Update</button>
        </form>
      </div>
    </div>
  );
};

export default EditKamar;
