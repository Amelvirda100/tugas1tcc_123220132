import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const KamarList = () => {
  const [kamar, setKamar] = useState([]);

  useEffect(() => {
    getKamar();
  }, []);

  const getKamar = async () => {
    try {
      const response = await axios.get('http://localhost:5000/kamar');
      setKamar(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  const deleteKamar = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/kamar/${id}`);
      getKamar();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="columns is-centered mt-5">
      <div className="column is-half">
        <Link to={'/add-kamar'} className="button is-primary is-light" style={{ marginBottom: '20px' }}>Tambah Kamar</Link>
        <table className="table is-striped is-fullwidth">
          <thead>
            <tr>
              <th>No</th>
              <th>Nomor Kamar</th>
              <th>Tipe</th>
              <th>Harga</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {kamar.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td>{item.nomor}</td>
                <td>{item.tipe}</td>
                <td>{item.harga}</td>
                <td>
                  <Link to={`/edit-kamar/${item.id}`} className="button is-small is-info is-light">Edit</Link>
                  <button onClick={() => deleteKamar(item.id)} className="button is-small is-danger is-light">Hapus</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default KamarList;
