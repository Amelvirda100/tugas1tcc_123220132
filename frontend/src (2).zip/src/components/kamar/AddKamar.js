import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AddKamar = () => {
  const [nomor_kamar, setNomorKamar] = useState('');
  const [tipe_kamar, setTipeKamar] = useState('');
  const [harga, setHarga] = useState('');
  const [status, setStatus] = useState('kosong');
  const [fasilitas, setFasilitas] = useState('');
  const navigate = useNavigate();

  const saveKamar = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/kamar', {
        nomor_kamar,
        tipe_kamar,
        harga,
        status,
        fasilitas
      });
      navigate('/kamar'); // diarahkan ke daftar kamar
    } catch (error) {
      console.error(error);
      alert('Gagal menyimpan kamar');
    }
  };

  return (
    <div className="columns is-centered mt-5">
      <div className="column is-half">
        <form onSubmit={saveKamar} className="box">
          <h3 className="title is-4">Tambah Kamar</h3>

          <div className="field">
            <label className="label">Nomor Kamar</label>
            <input className="input" type="text" value={nomor_kamar} onChange={(e) => setNomorKamar(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Tipe Kamar</label>
            <input className="input" type="text" value={tipe_kamar} onChange={(e) => setTipeKamar(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Harga</label>
            <input className="input" type="number" value={harga} onChange={(e) => setHarga(e.target.value)} />
          </div>

          <div className="field">
            <label className="label">Fasilitas</label>
            <textarea
              className="textarea"
              value={fasilitas}
              onChange={(e) => setFasilitas(e.target.value)}
              placeholder="Masukkan fasilitas, pisahkan dengan koma"
            />
          </div>

            <div className="field">
              <label className="label">Status</label>
              <input className="input" type="text" value="kosong" disabled />
            </div>

          <button type="submit" className="button is-primary is-light mt-4">💾 Simpan</button>
        </form>
      </div>
    </div>
  );
};

export default AddKamar;
